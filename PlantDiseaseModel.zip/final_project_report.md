# Final Project Report - Plant Disease Classification (CNN)

## 1. What was built
An image classifier that takes a leaf photo and predicts one of 38 PlantVillage classes (crop + disease or healthy).
Model: MobileNetV2 pretrained on ImageNet used as a feature extractor + new classification head, trained in two stages
(head only, then fine-tuning the top 30% of backbone layers). Pipeline code is written from scratch; only the feature-extractor weights are pretrained.

## 2. Data and leakage control
- Dataset: PlantVillage `color` folder, 54,305 image files found, 54,305 valid, 0 invalid (excluded, not deleted).
- Duplicate checks: 21 exact duplicate files, 722 files with flip/rotate/copy-style names, near-duplicate links: 420. Related images were grouped and kept in the same subset.
- Split before augmentation, seed 42: train 37,992 (70.0%), validation 8,158 (15.0%), test 8,155 (15.0%).
- Limit: different photos of the same physical leaf cannot be detected, so leakage prevention is not guaranteed to be complete.

## 3. Training
Stage A (frozen backbone) then Stage B (fine-tuning, LR 1e-05). Early stopping on validation loss, best-weights restore, LR reduction on plateau.
Selected checkpoint: stage B (chosen on validation loss only). Validation accuracy of selected model: 0.9750.

## 4. Test results (evaluated once on held-out data)
- Accuracy 0.9761, loss 0.0769, top-3 accuracy 0.9977
- Macro F1 0.9721, weighted F1 0.9760
- Total test errors: 195 of 8155. See classification_report.txt and confusion matrices for per-class results.

## 5. Over/under-fitting diagnosis
Train(un-augmented subset) accuracy 0.9828 vs validation accuracy 0.9750 (gap 0.0078).
Findings: [WEAK CLASSES] validation recall < 0.85 for: [('Tomato___Early_blight', 0.693)].

## 6. Limitations
- Lab-style PlantVillage images; field performance is UNVERIFIED without a separate field dataset.
- Softmax confidence is not calibrated; unknown diseases/out-of-distribution images are not reliably detected. Warning threshold = 0.8.
- Classifier only: it does not measure soil moisture, weather, irrigation need, yield or pests, and gives no treatment advice (use verified agricultural guidance).

## 7. Integration
`inference.py` returns JSON-friendly output (predicted class, confidence, top-3, timestamp, model version, warning flag) so a web dashboard or other module can call it independently of the soil/weather/irrigation/yield modules.

## 8. Viva - simple answers
- **What is a CNN?** A neural network that learns visual patterns (edges -> textures -> leaf spots) with small sliding filters.
- **Why transfer learning?** MobileNetV2 already learned general visual features from ImageNet, so we need less data/time and usually generalise better than training from scratch.
- **Why two stages?** First train the new head safely; then gently adjust the top layers with a tiny learning rate so we do not destroy useful pretrained features.
- **Why split before augmentation, and why group duplicates?** Otherwise copies of the same image land in train and test and the score looks better than reality (data leakage).
- **Why validation AND test sets?** Validation guides decisions (early stopping, model choice). The test set is touched once so the final score is honest.
- **Overfitting?** Train score much better than validation score / validation loss rising. Fixes: more regularisation, augmentation, less fine-tuning.
- **Underfitting?** Both scores poor. Fixes: fine-tune more, train longer, check preprocessing/labels.
- **Why precision/recall/F1 and a confusion matrix, not only accuracy?** Accuracy hides weak small classes; these show which diseases get confused.
- **Is it ready for farms?** Not proven. It needs testing on real field photos, and confidence warnings only reduce, not remove, wrong answers.
