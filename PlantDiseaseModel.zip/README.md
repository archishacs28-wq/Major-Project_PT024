# Plant Disease Classification Model (PlantVillage, color images)

Part of the project: AI Based Precision Agriculture and Crop Health Monitoring System.
Version 1.0.0 - backbone MobileNetV2 (ImageNet-pretrained) with a new head, trained with two-stage transfer learning.

## Measured results (held-out test set, evaluated once)
- Test images: 8,155
- Test accuracy: 0.9761 | Test loss: 0.0769
- Macro F1: 0.9721 | Weighted F1: 0.9760
- Classes: 38. See classification_report.txt and the confusion matrices for per-class detail.

## Files
best_plant_disease_model.keras, class_names.json, model_config.json, inference.py, requirements.txt,
dataset_split_manifest.csv, training_history.csv/png, confusion_matrix.png, normalized_confusion_matrix.png,
classification_report.txt, test_results.json, plant_disease_model.tflite (optional), checkpoints/.

## Use
    pip install -r requirements.txt
    python inference.py leaf.jpg
or
    from inference import PlantDiseasePredictor
    result = PlantDiseasePredictor().predict('leaf.jpg')

The result is JSON-friendly: predicted_class, crop, condition, confidence, top_k, low_confidence_warning,
warning_message, timestamp_utc, model_version, status. Input images are resized to 224x224;
scaling is done inside the model (do not normalise images yourself).

## Limitations (please read)
- PlantVillage photos are clean, lab-style leaf images. High test accuracy here does NOT prove field accuracy; real-world generalization is unverified unless tested on separate field images.
- Softmax confidence is not a calibrated probability. Images of other plants, unknown diseases, pests, or non-leaf objects can still receive confident wrong predictions. Warnings below 0.80 confidence are a heuristic.
- Duplicate/near-duplicate grouping reduces leakage but cannot detect different photos of the same physical leaf.
- This module only classifies leaf images. It does not measure soil moisture, weather, irrigation needs or yield, and it contains no treatment advice; any treatment guidance must come from verified agricultural sources.
