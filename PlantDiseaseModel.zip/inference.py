# inference.py - reusable plant disease predictor (does NOT retrain anything).
# Usage from Python:   from inference import PlantDiseasePredictor
#                      p = PlantDiseasePredictor(); print(p.predict('leaf.jpg'))
# Usage from terminal: python inference.py leaf1.jpg leaf2.jpg
import json
import sys
import datetime
from pathlib import Path

import numpy as np
import tensorflow as tf
from tensorflow import keras
from PIL import Image

HERE = Path(__file__).resolve().parent


def split_label(name):
    # 'Tomato___Early_blight' -> ('Tomato', 'Early blight')
    if '___' in name:
        crop, cond = name.split('___', 1)
    else:
        crop, cond = '', name
    return crop.replace('_', ' ').strip(' _'), cond.replace('_', ' ').strip(' _')


class PlantDiseasePredictor:
    def __init__(self, model_dir=None, threshold=None):
        self.model_dir = Path(model_dir) if model_dir else HERE
        cfg = json.loads((self.model_dir / 'model_config.json').read_text())
        self.config = cfg
        self.class_names = json.loads((self.model_dir / 'class_names.json').read_text())
        self.img_size = tuple(cfg['img_size'])
        self.threshold = float(threshold if threshold is not None else cfg['confidence_threshold'])
        self.model_version = cfg['model_version']
        model_path = self.model_dir / cfg['model_file']
        if not model_path.exists():
            raise FileNotFoundError('Model file not found: ' + str(model_path))
        self.model = keras.models.load_model(model_path, compile=False)
        if self.model.output_shape[-1] != len(self.class_names):
            raise ValueError('Model output size does not match class_names.json')

    def _to_tensor(self, image):
        # identical to the training/evaluation pipeline: decode -> RGB -> tf.image.resize -> float32 (0..255)
        if isinstance(image, (str, Path)):
            path = Path(image)
            if not path.exists():
                raise FileNotFoundError('Image file not found: ' + str(path))
            raw = tf.io.read_file(str(path))
            img = tf.io.decode_image(raw, channels=3, expand_animations=False)
        elif isinstance(image, Image.Image):
            img = tf.convert_to_tensor(np.asarray(image.convert('RGB'), dtype=np.uint8))
        elif isinstance(image, np.ndarray):
            arr = image
            if arr.ndim == 2:
                arr = np.stack([arr] * 3, axis=-1)
            if arr.ndim != 3 or arr.shape[-1] not in (3, 4):
                raise ValueError('Array must be HxW, HxWx3 or HxWx4, got shape ' + str(arr.shape))
            img = tf.convert_to_tensor(np.clip(arr[..., :3], 0, 255).astype(np.uint8))
        else:
            raise TypeError('image must be a file path, PIL image or numpy array, got ' + str(type(image)))
        img = tf.image.resize(img, self.img_size)
        return tf.cast(img, tf.float32)

    def predict(self, image, top_k=3):
        base = {'timestamp_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'model_version': self.model_version}
        try:
            x = self._to_tensor(image)
            probs = self.model(x[None, ...], training=False).numpy()[0]
        except Exception as e:
            return dict(base, status='error', error=type(e).__name__ + ': ' + str(e))
        if not np.all(np.isfinite(probs)):
            return dict(base, status='error', error='Model produced non-finite probabilities')
        order = np.argsort(probs)[::-1][:top_k]
        top = [{'class': self.class_names[i], 'confidence': round(float(probs[i]), 6)} for i in order]
        best = int(order[0])
        conf = float(probs[best])
        crop, cond = split_label(self.class_names[best])
        low = conf < self.threshold
        return dict(base, status='ok', predicted_class=self.class_names[best], crop=crop, condition=cond,
                    is_healthy=('healthy' in cond.lower()), confidence=round(conf, 6), top_k=top,
                    low_confidence_warning=bool(low), confidence_threshold=self.threshold,
                    warning_message=('Uncertain prediction: confidence below threshold. Retake the photo or consult an expert.' if low else ''))


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Usage: python inference.py <image1> [image2 ...]')
        sys.exit(1)
    predictor = PlantDiseasePredictor()
    out = [dict(image=a, **predictor.predict(a)) for a in sys.argv[1:]]
    print(json.dumps(out, indent=2))
