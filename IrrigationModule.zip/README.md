# Irrigation module
Files: irrigation_model.pkl (model bundle), irrigation_inference.py (advise()), model_config.json, test_results.json,
policy_comparison.csv, final_project_report.md, plots. Usage:
    import irrigation_inference as ii; b = ii.load('irrigation_model.pkl')
    ii.advise(b, crop='Wheat', soil='loam', das=60, vwc=0.21, rain_next2=0)
Wheat/Mustard use the ML model (needs a soil-moisture reading); Rice uses a standing-water rule.
Trained on SIMULATED soil moisture; retrain on real sensor logs when available.
