
import joblib, datetime, numpy as np, pandas as pd

def load(path='irrigation_model.pkl'):
    return joblib.load(path)

def root_depth(b, crop, das):
    cp = b['crops'][crop]; r0, r1 = cp['root']
    return r0 + (r1 - r0) * min(das / (cp['stages'][0] + cp['stages'][1]), 1.0)

def et0_hargreaves(lat, doy, tmax, tmean):
    """ET0 (mm/day) from forecast Tmax/Tmean, latitude and day of year (Tmin ~ 2*Tmean - Tmax)."""
    tmin = min(2 * tmean - tmax, tmean); phi = np.radians(lat)
    dr = 1 + 0.033 * np.cos(2 * np.pi * doy / 365); dec = 0.409 * np.sin(2 * np.pi * doy / 365 - 1.39)
    ws = np.arccos(np.clip(-np.tan(phi) * np.tan(dec), -1, 1))
    ra = (24 * 60 / np.pi) * 0.0820 * dr * (ws * np.sin(phi) * np.sin(dec) + np.cos(phi) * np.cos(dec) * np.sin(ws))
    return float(max(0.0023 * 0.408 * ra * (tmean + 17.8) * np.sqrt(max(tmax - tmin, 0.1)), 0))

def kc_at(b, crop, das):
    ini, dev, mid, late = b['crops'][crop]['stages']; ki, km, ke = b['crops'][crop]['kc']
    if das < ini: return ki
    if das < ini + dev: return ki + (km - ki) * (das - ini) / dev
    if das < ini + dev + mid: return km
    return km + (ke - km) * (das - ini - dev - mid) / late

def _features(b, crop, soil, vwc, das, tmax, tmean, rh, rain_today, rain_next2, lat, doy):
    s = b['soils'][soil]; root = root_depth(b, crop, das)
    dep = max((s['fc'] - vwc) * root * 1000, 0.0); taw = (s['fc'] - s['wp']) * root * 1000
    row = dict(vwc=vwc, fc=s['fc'], wp=s['wp'], dep_mm=dep, dep_frac=dep / taw, tmax=tmax, tmean=tmean, rh=rh,
               rain=rain_today, rain_next2=rain_next2, et0=et0_hargreaves(lat, doy, tmax, tmean), das=das,
               is_wheat=int(crop == 'Wheat'))
    return pd.DataFrame([row])[b['features']]

def advise(b, crop, soil='loam', das=30, vwc=None, ponded_mm=None, tmax=30.0, tmean=22.0, rh=50.0,
           rain_today=0.0, rain_next2=0.0, lat=29.5, doy=None):
    """Irrigation advice. Wheat/Mustard: pass vwc (0-1, e.g. 0.22) and soil. Rice: pass ponded_mm.
    rain_today / rain_next2 are forecast mm. Returns action, amount (mm), probability and reason."""
    doy = doy or datetime.date.today().timetuple().tm_yday
    if crop == 'Rice':
        if ponded_mm is None: raise ValueError('Rice needs ponded_mm')
        if ponded_mm >= 20:
            return dict(action='No irrigation needed', amount_mm=0, probability=None, reason='Standing water %.0f mm (>= 20 mm).' % ponded_mm)
        if rain_today + rain_next2 >= 20:
            return dict(action='Wait: rain expected', amount_mm=0, probability=None, reason='%.0f mm rain forecast.' % (rain_today + rain_next2))
        return dict(action='Irrigate now', amount_mm=round(50 - ponded_mm), probability=None, reason='Standing water %.0f mm; refill to about 50 mm.' % ponded_mm)
    if vwc is None: raise ValueError('Wheat/Mustard need vwc')
    X = _features(b, crop, soil, vwc, das, tmax, tmean, rh, rain_today, rain_next2, lat, doy)
    prob = float(b['model'].predict_proba(X)[0, 1]); dep, frac = float(X.dep_mm[0]), float(X.dep_frac[0])
    rain = rain_today + rain_next2
    taw = float(X.dep_mm[0] / frac) if frac > 0 else (b['soils'][soil]['fc'] - b['soils'][soil]['wp']) * root_depth(b, crop, das) * 1000
    etc_day = max(float(X.et0[0]) * kc_at(b, crop, das), 0.1)
    eta = max((b['crops'][crop]['p'] * taw - dep) / etc_day, 0.0)          # rough days until irrigation is due
    if frac >= 0.85:
        return dict(action='Irrigate NOW (critical)', amount_mm=round(dep), probability=prob, days_until_needed=0.0,
                    reason='Root zone about %.0f%% depleted (soil moisture %.0f%%).' % (frac * 100, vwc * 100))
    if prob >= b['op_threshold']:
        if rain >= 15:
            return dict(action='Wait: rain expected', amount_mm=0, probability=prob, days_until_needed=round(eta, 1),
                        reason='%.0f mm rain forecast; recheck after it.' % rain)
        return dict(action='Irrigate today', amount_mm=round(dep), probability=prob, days_until_needed=0.0,
                    reason='Irrigation needed today; deficit about %.0f mm.' % dep)
    return dict(action='No irrigation needed today', amount_mm=0, probability=prob, days_until_needed=round(eta, 1),
                reason='Soil moisture %.0f%% is adequate; irrigation due in about %.0f days.' % (vwc * 100, eta))
