# Irrigation Module - Project Report

## 1. What was built
An irrigation advisor. For wheat and mustard, a Random Forest predicts whether irrigation is needed today from a soil-moisture
reading, soil type, weather and rain forecast; a rule converts that into an action and a water amount. Rice uses a standing-water rule.

## 2. Data (and its honest limits)
No public dataset links soil moisture to irrigation for Haryana farms, so soil moisture is **simulated**: real NASA POWER daily weather
(22 districts) drives an FAO-56 soil-water balance (Hargreaves ET0, crop coefficients by growth stage, growing root depth) for
3 soil types. Labels come from a perfect-knowledge reference policy. Sensor error (SD 0.015) and rain-forecast error (20% missed events,
5% false alarms, log-normal size error) are added to model inputs.

## 3. Evaluation design
Train 2010-2018, validation 2019, test 2020-2022; held-out districts: KAITHAL, BHIWANI, NUH, PANCHKULA.
Threshold 0.12 chosen on validation only; baselines tuned on training years; test set used once.

## 4. Test results
```
                           model     n  accuracy  precision  recall    f1   auc  brier
     Baseline: raw moisture rule 42120     0.937      0.166   0.247 0.198 0.714  0.031
        Baseline: depletion rule 42120     0.930      0.202   0.416 0.272 0.894  0.092
 Random Forest (realistic noise) 42120     0.924      0.236   0.631 0.344 0.930  0.026
Random Forest (unseen districts)  9360     0.922      0.229   0.662 0.340 0.937  0.024
 Random Forest (ideal, no noise) 42120     0.962      0.440   0.819 0.573 0.982  0.023
     Random Forest (harsh noise) 42120     0.816      0.093   0.552 0.159 0.772  0.037
```
## 5. Closed-loop water use on test seasons (noisy inputs)
```
   crop                           policy  irrigation_mm  n_irrigations  drainage_waste_mm  stress_days
Mustard Fixed calendar (60 mm / 21 days)          300.0            5.0              136.6          0.3
  Wheat Fixed calendar (60 mm / 21 days)          360.0            6.0              140.7         31.7
Mustard            Sensor threshold rule          248.7            3.9               79.4          0.1
  Wheat            Sensor threshold rule          392.4            5.8              106.5          2.9
Mustard          ML advisor (this model)          237.3            3.6               66.6          0.3
  Wheat          ML advisor (this model)          410.4            7.1              117.1          0.8
Mustard      Perfect-knowledge reference          171.4            2.8               12.5          0.0
  Wheat      Perfect-knowledge reference          301.9            5.3               17.4          0.0
```
- Wheat: ML advisor used 410 mm with 0.8 stress days vs fixed calendar 360 mm / 31.7 stress days (water saved vs fixed: -14%); vs sensor threshold rule 392 mm / 2.9 stress days.
- Mustard: ML advisor used 237 mm with 0.3 stress days vs fixed calendar 300 mm / 0.3 stress days (water saved vs fixed: 21%); vs sensor threshold rule 249 mm / 0.1 stress days.
## 6. Limitations
- Labels are simulated, so classification scores show the model learned the water-balance logic, not field validation.
- Soil parameters, Kc values, root depth and sowing dates are textbook assumptions, not measured per farm.
- Rain forecasts are simulated with noise; real forecast skill varies by place and season.
- Rice is rule-based; no ML for flooded paddy.
- Next step for real use: log sensor readings plus irrigation events and retrain.

## 7. Viva answers
- **Why simulate?** No public paired soil-moisture/irrigation data for Haryana; FAO-56 is the standard method, driven by real weather.
- **Isn't ML pointless if labels are rule-based?** The fair test is section 5: compare water used and stress days against a fixed calendar and a tuned sensor rule. The ML advisor combines forecast rain, soil type, crop stage and noisy sensors, but its edge over a good sensor rule is modest.
- **What is the baseline?** A depletion-threshold rule tuned on the same training years.
- **How do you avoid leakage?** Year-based split, held-out districts, threshold chosen on validation, test used once.
