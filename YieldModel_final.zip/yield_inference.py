
import joblib, pandas as pd
FEATS = ['rain_total','temp_mean','temp_max_mean','humidity_mean','rain_days']

def load(model_path='yield_model.pkl', climate_path='district_season_climate.csv'):
    return joblib.load(model_path), pd.read_csv(climate_path)

def predict_yield(bundle, climate, district, crop, season, area, **weather):
    district = district.upper()
    base = climate[(climate.district == district) & (climate.season == season)]
    if base.empty:
        raise ValueError('No climate data for this district/season')
    row = base.iloc[0][FEATS].to_dict()
    row.update({k: v for k, v in weather.items() if v is not None})
    row.update(district=district, crop=crop, season=season, area=area)
    X = pd.get_dummies(pd.DataFrame([row]), dtype=float)
    X = X.reindex(columns=bundle['columns'], fill_value=0.0)
    return float(bundle['model'].predict(X)[0])
